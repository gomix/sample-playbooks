<?php

namespace Defuse\Crypto\Exception;

class EnvironmentIsBrokenException extends \Defuse\Crypto\Exception\CryptoException
{
}
